import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, Modal, Alert } from 'react-native';
import { X, Clock, Users, Heart, ChefHat, Plus, Check } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { RecipeAPI } from '@/services/api';
import { useApp } from '@/contexts/AppContext';
import type { Recipe, RecipeDetails } from '@/types/recipe';

interface RecipeDetailModalProps {
  recipe: Recipe | null;
  visible: boolean;
  onClose: () => void;
}

export default function RecipeDetailModal({ recipe, visible, onClose }: RecipeDetailModalProps) {
  const [recipeDetails, setRecipeDetails] = useState<RecipeDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'ingredients' | 'instructions' | 'nutrition'>('ingredients');
  const { isRecipeLiked, toggleLikeRecipe, setPendingMealAddition } = useApp();
  const router = useRouter();

  useEffect(() => {
    if (recipe && visible) {
      loadRecipeDetails();
    }
  }, [recipe, visible]);

  const loadRecipeDetails = async () => {
    if (!recipe) return;
    
    setLoading(true);
    try {
      const details = await RecipeAPI.getRecipeInformation(recipe.id);
      setRecipeDetails(details);
    } catch (error) {
      console.error('Error loading recipe details:', error);
      Alert.alert('Error', 'Failed to load recipe details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const addToMealPlan = () => {
    if (!recipe) return;
    
    setPendingMealAddition({
      recipe,
      callback: (date: string, mealType: string) => {
        Alert.alert('Added!', `${recipe.title} has been added to your ${mealType} plan for ${new Date(date).toLocaleDateString()}.`);
      }
    });
    
    onClose();
    router.push('/(tabs)/meal-planner');
  };

  const addIngredientsToGroceryList = () => {
    Alert.alert(
      'Add to Grocery List',
      'All ingredients from this recipe will be added to your grocery list.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Add Ingredients', 
          onPress: () => {
            Alert.alert('Added!', 'Ingredients have been added to your grocery list.');
          }
        }
      ]
    );
  };

  const handleLikePress = () => {
    if (recipe) {
      toggleLikeRecipe(recipe.id);
    }
  };

  if (!recipe) return null;

  const displayRecipe = recipeDetails || recipe;
  const isLiked = isRecipeLiked(recipe.id);

  const renderIngredients = () => (
    <View style={styles.tabContent}>
      <View style={styles.ingredientsHeader}>
        <Text style={styles.ingredientsTitle}>Ingredients</Text>
        <TouchableOpacity 
          style={styles.addToListButton}
          onPress={addIngredientsToGroceryList}
        >
          <Plus color="#10B981" size={16} strokeWidth={2} />
          <Text style={styles.addToListText}>Add to List</Text>
        </TouchableOpacity>
      </View>
      
      {recipeDetails?.extendedIngredients ? (
        recipeDetails.extendedIngredients.map((ingredient, index) => (
          <View key={index} style={styles.ingredientItem}>
            <View style={styles.ingredientBullet} />
            <Text style={styles.ingredientText}>
              {ingredient.amount} {ingredient.unit} {ingredient.name}
            </Text>
          </View>
        ))
      ) : recipe.usedIngredients || recipe.missedIngredients ? (
        <>
          {recipe.usedIngredients?.map((ingredient, index) => (
            <View key={`used-${index}`} style={styles.ingredientItem}>
              <View style={styles.ingredientBullet} />
              <Text style={styles.ingredientText}>
                {ingredient.amount} {ingredient.unit} {ingredient.name}
              </Text>
            </View>
          ))}
          {recipe.missedIngredients?.map((ingredient, index) => (
            <View key={`missed-${index}`} style={styles.ingredientItem}>
              <View style={[styles.ingredientBullet, styles.missedBullet]} />
              <Text style={styles.ingredientText}>
                {ingredient.amount} {ingredient.unit} {ingredient.name}
              </Text>
            </View>
          ))}
        </>
      ) : (
        <Text style={styles.noDataText}>Ingredient information not available</Text>
      )}
    </View>
  );

  const renderInstructions = () => (
    <View style={styles.tabContent}>
      <Text style={styles.instructionsTitle}>Step-by-Step Instructions</Text>
      
      {recipeDetails?.analyzedInstructions?.[0]?.steps ? (
        recipeDetails.analyzedInstructions[0].steps.map((step, index) => (
          <View key={index} style={styles.instructionStep}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>{step.number}</Text>
            </View>
            <View style={styles.stepContent}>
              <Text style={styles.stepText}>{step.step}</Text>
              {step.ingredients && step.ingredients.length > 0 && (
                <View style={styles.stepIngredients}>
                  <Text style={styles.stepIngredientsTitle}>Ingredients needed:</Text>
                  <Text style={styles.stepIngredientsText}>
                    {step.ingredients.map(ing => ing.name).join(', ')}
                  </Text>
                </View>
              )}
              {step.equipment && step.equipment.length > 0 && (
                <View style={styles.stepEquipment}>
                  <Text style={styles.stepEquipmentTitle}>Equipment:</Text>
                  <Text style={styles.stepEquipmentText}>
                    {step.equipment.map(eq => eq.name).join(', ')}
                  </Text>
                </View>
              )}
            </View>
          </View>
        ))
      ) : recipeDetails?.instructions ? (
        <Text style={styles.simpleInstructions}>{recipeDetails.instructions}</Text>
      ) : (
        <View style={styles.noInstructionsContainer}>
          <ChefHat color="#D1D5DB" size={48} strokeWidth={2} />
          <Text style={styles.noInstructionsTitle}>Instructions Coming Soon</Text>
          <Text style={styles.noInstructionsText}>
            Detailed step-by-step cooking instructions will be available once the recipe data is fully loaded.
          </Text>
        </View>
      )}
    </View>
  );

  const renderNutrition = () => (
    <View style={styles.tabContent}>
      <Text style={styles.nutritionTitle}>Nutrition & Details</Text>
      
      <View style={styles.nutritionGrid}>
        {recipeDetails?.healthScore && (
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{recipeDetails.healthScore}</Text>
            <Text style={styles.nutritionLabel}>Health Score</Text>
          </View>
        )}
        {recipeDetails?.pricePerServing && (
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>${(recipeDetails.pricePerServing / 100).toFixed(2)}</Text>
            <Text style={styles.nutritionLabel}>Per Serving</Text>
          </View>
        )}
        {displayRecipe.readyInMinutes && (
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{displayRecipe.readyInMinutes}</Text>
            <Text style={styles.nutritionLabel}>Minutes</Text>
          </View>
        )}
        {displayRecipe.servings && (
          <View style={styles.nutritionItem}>
            <Text style={styles.nutritionValue}>{displayRecipe.servings}</Text>
            <Text style={styles.nutritionLabel}>Servings</Text>
          </View>
        )}
      </View>

      {recipeDetails && (
        <View style={styles.dietTags}>
          {recipeDetails.vegetarian && <View style={styles.dietTag}><Text style={styles.dietTagText}>Vegetarian</Text></View>}
          {recipeDetails.vegan && <View style={styles.dietTag}><Text style={styles.dietTagText}>Vegan</Text></View>}
          {recipeDetails.glutenFree && <View style={styles.dietTag}><Text style={styles.dietTagText}>Gluten Free</Text></View>}
          {recipeDetails.dairyFree && <View style={styles.dietTag}><Text style={styles.dietTagText}>Dairy Free</Text></View>}
          {recipeDetails.veryHealthy && <View style={styles.dietTag}><Text style={styles.dietTagText}>Very Healthy</Text></View>}
        </View>
      )}

      {recipeDetails?.summary && (
        <View style={styles.summarySection}>
          <Text style={styles.summaryTitle}>About This Recipe</Text>
          <Text style={styles.summaryText}>
            {recipeDetails.summary.replace(/<[^>]*>/g, '')}
          </Text>
        </View>
      )}
    </View>
  );

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <X color="#6B7280" size={24} strokeWidth={2} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Recipe Details</Text>
          <TouchableOpacity style={styles.heartButton} onPress={handleLikePress}>
            <Heart 
              color={isLiked ? "#EF4444" : "#6B7280"} 
              size={24} 
              strokeWidth={2}
              fill={isLiked ? "#EF4444" : "transparent"}
            />
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {/* Recipe Image */}
          <Image 
            source={{ uri: displayRecipe.image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg' }} 
            style={styles.image}
            resizeMode="cover"
          />

          {/* Recipe Info */}
          <View style={styles.recipeInfo}>
            <Text style={styles.recipeTitle}>{displayRecipe.title}</Text>
            
            <View style={styles.recipeStats}>
              <View style={styles.statItem}>
                <Clock color="#6B7280" size={20} strokeWidth={2} />
                <Text style={styles.statText}>{displayRecipe.readyInMinutes || 30} min</Text>
              </View>
              <View style={styles.statItem}>
                <Users color="#6B7280" size={20} strokeWidth={2} />
                <Text style={styles.statText}>{displayRecipe.servings || 4} servings</Text>
              </View>
              <View style={styles.statItem}>
                <Heart color="#EF4444" size={20} strokeWidth={2} />
                <Text style={styles.statText}>{displayRecipe.aggregateLikes || displayRecipe.likes || 0}</Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.primaryButton} onPress={addToMealPlan}>
              <ChefHat color="#FFFFFF" size={20} strokeWidth={2} />
              <Text style={styles.primaryButtonText}>Add to Meal Plan</Text>
            </TouchableOpacity>
          </View>

          {/* Tabs */}
          <View style={styles.tabsContainer}>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'ingredients' && styles.activeTab]}
              onPress={() => setActiveTab('ingredients')}
            >
              <Text style={[styles.tabText, activeTab === 'ingredients' && styles.activeTabText]}>
                Ingredients
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'instructions' && styles.activeTab]}
              onPress={() => setActiveTab('instructions')}
            >
              <Text style={[styles.tabText, activeTab === 'instructions' && styles.activeTabText]}>
                Instructions
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.tab, activeTab === 'nutrition' && styles.activeTab]}
              onPress={() => setActiveTab('nutrition')}
            >
              <Text style={[styles.tabText, activeTab === 'nutrition' && styles.activeTabText]}>
                Nutrition
              </Text>
            </TouchableOpacity>
          </View>

          {/* Tab Content */}
          {loading ? (
            <View style={styles.loadingContainer}>
              <Text style={styles.loadingText}>Loading recipe details...</Text>
            </View>
          ) : (
            <>
              {activeTab === 'ingredients' && renderIngredients()}
              {activeTab === 'instructions' && renderInstructions()}
              {activeTab === 'nutrition' && renderNutrition()}
            </>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  closeButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  heartButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
  },
  image: {
    width: '100%',
    height: 300,
  },
  recipeInfo: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    marginTop: -20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  recipeTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
    lineHeight: 32,
  },
  recipeStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 16,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  actionButtons: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  primaryButton: {
    backgroundColor: '#10B981',
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    shadowColor: '#10B981',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  primaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 4,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#10B981',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  tabContent: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 16,
    padding: 20,
    marginBottom: 32,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  ingredientsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  ingredientsTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  addToListButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ECFDF5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  addToListText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
    marginLeft: 4,
  },
  ingredientItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  ingredientBullet: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
    marginRight: 12,
  },
  missedBullet: {
    backgroundColor: '#F59E0B',
  },
  ingredientText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    flex: 1,
  },
  noDataText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    fontStyle: 'italic',
    paddingVertical: 20,
  },
  instructionsTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 20,
  },
  instructionStep: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
    marginTop: 4,
  },
  stepNumberText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  stepContent: {
    flex: 1,
  },
  stepText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 24,
    marginBottom: 8,
  },
  stepIngredients: {
    backgroundColor: '#F0FDF4',
    padding: 8,
    borderRadius: 8,
    marginBottom: 4,
  },
  stepIngredientsTitle: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#047857',
    marginBottom: 2,
  },
  stepIngredientsText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#065F46',
  },
  stepEquipment: {
    backgroundColor: '#FEF3C7',
    padding: 8,
    borderRadius: 8,
  },
  stepEquipmentTitle: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#92400E',
    marginBottom: 2,
  },
  stepEquipmentText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#78350F',
  },
  simpleInstructions: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    lineHeight: 24,
  },
  noInstructionsContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  noInstructionsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#374151',
    marginTop: 16,
    marginBottom: 8,
  },
  noInstructionsText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  nutritionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  nutritionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  nutritionItem: {
    width: '48%',
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  nutritionValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
    marginBottom: 4,
  },
  nutritionLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  dietTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 20,
  },
  dietTag: {
    backgroundColor: '#ECFDF5',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  dietTagText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#047857',
  },
  summarySection: {
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingTop: 16,
  },
  summaryTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  summaryText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
  },
});