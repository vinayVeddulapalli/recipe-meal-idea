import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Clock, Users, Heart, ChefHat } from 'lucide-react-native';
import { useApp } from '@/contexts/AppContext';
import type { Recipe } from '@/types/recipe';

interface RecipeCardProps {
  recipe: Recipe;
  onPress: (recipe: Recipe) => void;
  showStats?: boolean;
  variant?: 'default' | 'trending';
}

export default function RecipeCard({ recipe, onPress, showStats = true, variant = 'default' }: RecipeCardProps) {
  const { isRecipeLiked, toggleLikeRecipe } = useApp();
  const isTrending = variant === 'trending';
  const isLiked = isRecipeLiked(recipe.id);
  
  const handleLikePress = (e: any) => {
    e.stopPropagation();
    toggleLikeRecipe(recipe.id);
  };

  return (
    <TouchableOpacity 
      style={[styles.card, isTrending && styles.trendingCard]} 
      onPress={() => onPress(recipe)}
    >
      {/* Recipe Image */}
      <View style={styles.imageContainer}>
        <Image 
          source={{ uri: recipe.image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg' }} 
          style={[styles.image, isTrending && styles.trendingImage]}
          resizeMode="cover"
        />
        
        {/* Cuisine Badge */}
        {recipe.cuisines && recipe.cuisines.length > 0 && (
          <View style={styles.cuisineBadge}>
            <Text style={styles.cuisineText}>{recipe.cuisines[0]}</Text>
          </View>
        )}
        
        {/* Heart Icon */}
        <TouchableOpacity style={styles.heartButton} onPress={handleLikePress}>
          <Heart 
            color={isLiked ? "#EF4444" : "#FFFFFF"} 
            size={20} 
            strokeWidth={2} 
            fill={isLiked ? "#EF4444" : "rgba(255,255,255,0.2)"}
          />
        </TouchableOpacity>
      </View>

      <View style={[styles.content, isTrending && styles.trendingContent]}>
        <Text style={[styles.title, isTrending && styles.trendingTitle]} numberOfLines={2}>
          {recipe.title}
        </Text>
        
        {showStats && recipe.usedIngredientCount !== undefined && (
          <View style={styles.ingredientStats}>
            <View style={styles.statItem}>
              <ChefHat color="#10B981" size={16} strokeWidth={2} />
              <Text style={styles.statText}>
                Used: {recipe.usedIngredientCount}
              </Text>
            </View>
            <View style={styles.statItem}>
              <Clock color="#F59E0B" size={16} strokeWidth={2} />
              <Text style={styles.statText}>
                Missing: {recipe.missedIngredientCount}
              </Text>
            </View>
            <View style={styles.statItem}>
              <Heart color="#EF4444" size={16} strokeWidth={2} />
              <Text style={styles.statText}>
                {recipe.likes || 0}
              </Text>
            </View>
          </View>
        )}

        {/* Recipe Stats */}
        <View style={styles.recipeStats}>
          {recipe.readyInMinutes && (
            <View style={styles.statItem}>
              <Clock color="#6B7280" size={14} strokeWidth={2} />
              <Text style={styles.recipeStatText}>{recipe.readyInMinutes} min</Text>
            </View>
          )}
          {recipe.servings && (
            <View style={styles.statItem}>
              <Users color="#6B7280" size={14} strokeWidth={2} />
              <Text style={styles.recipeStatText}>{recipe.servings} servings</Text>
            </View>
          )}
          {recipe.healthScore && (
            <View style={styles.statItem}>
              <Text style={styles.healthScore}>❤️ {recipe.healthScore}</Text>
            </View>
          )}
        </View>
        
        {recipe.missedIngredients && recipe.missedIngredients.length > 0 && showStats && (
          <View style={styles.missingIngredients}>
            <Text style={styles.missingLabel}>Missing:</Text>
            <Text style={styles.missingText} numberOfLines={2}>
              {recipe.missedIngredients.map(ing => ing.name).join(', ')}
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
    overflow: 'hidden',
  },
  trendingCard: {
    marginHorizontal: 0,
    width: '100%',
  },
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: 200,
  },
  trendingImage: {
    height: 160,
  },
  cuisineBadge: {
    position: 'absolute',
    top: 12,
    left: 12,
    backgroundColor: '#F59E0B',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  cuisineText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  heartButton: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderRadius: 20,
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    padding: 16,
  },
  trendingContent: {
    padding: 12,
  },
  title: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 12,
    lineHeight: 24,
  },
  trendingTitle: {
    fontSize: 16,
    marginBottom: 8,
  },
  ingredientStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingVertical: 8,
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    paddingHorizontal: 8,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  recipeStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  recipeStatText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  healthScore: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
  },
  missingIngredients: {
    backgroundColor: '#FEF3C7',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#F59E0B',
  },
  missingLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#92400E',
    marginBottom: 4,
  },
  missingText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#78350F',
    lineHeight: 20,
  },
});