import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { Plus, X } from 'lucide-react-native';

interface IngredientInputProps {
  ingredients: string[];
  onIngredientsChange: (ingredients: string[]) => void;
  placeholder?: string;
}

export default function IngredientInput({ 
  ingredients, 
  onIngredientsChange, 
  placeholder = "Enter ingredient..." 
}: IngredientInputProps) {
  const [inputValue, setInputValue] = useState('');

  const addIngredient = () => {
    if (inputValue.trim() && !ingredients.includes(inputValue.trim().toLowerCase())) {
      onIngredientsChange([...ingredients, inputValue.trim().toLowerCase()]);
      setInputValue('');
    }
  };

  const removeIngredient = (index: number) => {
    const newIngredients = ingredients.filter((_, i) => i !== index);
    onIngredientsChange(newIngredients);
  };

  const handleSubmitEditing = () => {
    addIngredient();
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={inputValue}
          onChangeText={setInputValue}
          placeholder={placeholder}
          placeholderTextColor="#9CA3AF"
          onSubmitEditing={handleSubmitEditing}
          returnKeyType="done"
        />
        <TouchableOpacity 
          style={[styles.addButton, !inputValue.trim() && styles.addButtonDisabled]} 
          onPress={addIngredient}
          disabled={!inputValue.trim()}
        >
          <Plus color={!inputValue.trim() ? "#D1D5DB" : "#FFFFFF"} size={20} strokeWidth={2} />
        </TouchableOpacity>
      </View>

      {ingredients.length > 0 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.ingredientsContainer}>
          {ingredients.map((ingredient, index) => (
            <View key={index} style={styles.ingredientTag}>
              <Text style={styles.ingredientText}>
                {ingredient.charAt(0).toUpperCase() + ingredient.slice(1)}
              </Text>
              <TouchableOpacity 
                onPress={() => removeIngredient(index)}
                style={styles.removeButton}
              >
                <X color="#EF4444" size={16} strokeWidth={2} />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      )}

      {ingredients.length === 0 && (
        <Text style={styles.emptyText}>
          Add ingredients you have available to find matching recipes
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    marginVertical: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    paddingHorizontal: 16,
    paddingVertical: 4,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#111827',
    paddingVertical: 12,
  },
  addButton: {
    backgroundColor: '#10B981',
    borderRadius: 8,
    padding: 8,
    marginLeft: 8,
  },
  addButtonDisabled: {
    backgroundColor: '#F3F4F6',
  },
  ingredientsContainer: {
    marginTop: 16,
  },
  ingredientTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ECFDF5',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  ingredientText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#047857',
    marginRight: 6,
  },
  removeButton: {
    padding: 2,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 16,
    lineHeight: 20,
  },
});