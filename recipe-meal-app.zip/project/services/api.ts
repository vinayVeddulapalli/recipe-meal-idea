// Replace 'YOUR_NEW_API_KEY_HERE' with your actual Spoonacular API key
const API_KEY = 'ffb8df44661b4164baaf056bbee5c651';
const BASE_URL = 'https://api.spoonacular.com';

export class RecipeAPI {
  static async searchRecipesByIngredients(
    ingredients: string[],
    number: number = 12,
    ranking: number = 1,
    ignorePantry: boolean = true
  ) {
    const ingredientsString = ingredients.join(',+');
    const url = `${BASE_URL}/recipes/findByIngredients?apiKey=${API_KEY}&ingredients=${ingredientsString}&number=${number}&ranking=${ranking}&ignorePantry=${ignorePantry}`;
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error searching recipes by ingredients:', error);
      throw error;
    }
  }

  static async getRecipeInformation(id: number) {
    const url = `${BASE_URL}/recipes/${id}/information?apiKey=${API_KEY}&includeNutrition=true`;
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error getting recipe information:', error);
      throw error;
    }
  }

  static async searchRecipes(
    query: string,
    diet?: string,
    intolerances?: string,
    number: number = 12,
    offset: number = 0
  ) {
    let url = `${BASE_URL}/recipes/complexSearch?apiKey=${API_KEY}&query=${encodeURIComponent(query)}&number=${number}&offset=${offset}&addRecipeInformation=true&fillIngredients=true`;
    
    if (diet) {
      url += `&diet=${diet}`;
    }
    if (intolerances) {
      url += `&intolerances=${intolerances}`;
    }
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error searching recipes:', error);
      throw error;
    }
  }

  static async getRandomRecipes(
    number: number = 12,
    tags?: string
  ) {
    let url = `${BASE_URL}/recipes/random?apiKey=${API_KEY}&number=${number}`;
    
    if (tags) {
      url += `&tags=${tags}`;
    }
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error getting random recipes:', error);
      throw error;
    }
  }

  static async getSimilarRecipes(id: number, number: number = 3) {
    const url = `${BASE_URL}/recipes/${id}/similar?apiKey=${API_KEY}&number=${number}`;
    
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error getting similar recipes:', error);
      throw error;
    }
  }
}