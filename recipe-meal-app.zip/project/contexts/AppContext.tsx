import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Recipe, MealPlan, GroceryItem } from '@/types/recipe';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

interface AppContextType {
  // User state
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;

  // Liked recipes
  likedRecipes: Set<number>;
  toggleLikeRecipe: (recipeId: number) => void;
  isRecipeLiked: (recipeId: number) => boolean;

  // Meal plans
  mealPlans: MealPlan[];
  addRecipeToMealPlan: (recipe: Recipe, date: string, mealType: 'breakfast' | 'lunch' | 'dinner') => void;
  removeMealFromPlan: (date: string, mealType: 'breakfast' | 'lunch' | 'dinner') => void;
  getMealPlan: (date: string) => MealPlan | undefined;

  // Grocery list
  groceryItems: GroceryItem[];
  addGroceryItem: (item: Omit<GroceryItem, 'id'>) => void;
  removeGroceryItem: (id: string) => void;
  toggleGroceryItem: (id: string) => void;
  clearCheckedItems: () => void;
  addRecipeIngredientsToGrocery: (recipe: Recipe) => void;

  // Pending meal addition
  pendingMealAddition: { recipe: Recipe; callback: (date: string, mealType: string) => void } | null;
  setPendingMealAddition: (data: { recipe: Recipe; callback: (date: string, mealType: string) => void } | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [likedRecipes, setLikedRecipes] = useState<Set<number>>(new Set());
  const [mealPlans, setMealPlans] = useState<MealPlan[]>([]);
  const [groceryItems, setGroceryItems] = useState<GroceryItem[]>([]);
  const [pendingMealAddition, setPendingMealAddition] = useState<{ recipe: Recipe; callback: (date: string, mealType: string) => void } | null>(null);

  // Load data from storage on app start
  useEffect(() => {
    loadStoredData();
  }, []);

  // Save data to storage whenever state changes
  useEffect(() => {
    saveDataToStorage();
  }, [user, likedRecipes, mealPlans, groceryItems]);

  const loadStoredData = async () => {
    try {
      const [storedUser, storedLikes, storedMeals, storedGrocery] = await Promise.all([
        AsyncStorage.getItem('user'),
        AsyncStorage.getItem('likedRecipes'),
        AsyncStorage.getItem('mealPlans'),
        AsyncStorage.getItem('groceryItems')
      ]);

      if (storedUser) setUser(JSON.parse(storedUser));
      if (storedLikes) setLikedRecipes(new Set(JSON.parse(storedLikes)));
      if (storedMeals) setMealPlans(JSON.parse(storedMeals));
      if (storedGrocery) setGroceryItems(JSON.parse(storedGrocery));
    } catch (error) {
      console.error('Error loading stored data:', error);
    }
  };

  const saveDataToStorage = async () => {
    try {
      await Promise.all([
        AsyncStorage.setItem('user', JSON.stringify(user)),
        AsyncStorage.setItem('likedRecipes', JSON.stringify(Array.from(likedRecipes))),
        AsyncStorage.setItem('mealPlans', JSON.stringify(mealPlans)),
        AsyncStorage.setItem('groceryItems', JSON.stringify(groceryItems))
      ]);
    } catch (error) {
      console.error('Error saving data to storage:', error);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // For demo purposes, accept any email/password combination
    if (email && password) {
      const newUser: User = {
        id: Date.now().toString(),
        name: email.split('@')[0].replace(/[^a-zA-Z]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        email: email,
        avatar: `https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2`
      };
      setUser(newUser);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    AsyncStorage.removeItem('user');
  };

  const updateProfile = (updates: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...updates });
    }
  };

  const toggleLikeRecipe = (recipeId: number) => {
    setLikedRecipes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(recipeId)) {
        newSet.delete(recipeId);
      } else {
        newSet.add(recipeId);
      }
      return newSet;
    });
  };

  const isRecipeLiked = (recipeId: number) => {
    return likedRecipes.has(recipeId);
  };

  const addRecipeToMealPlan = (recipe: Recipe, date: string, mealType: 'breakfast' | 'lunch' | 'dinner') => {
    setMealPlans(prev => {
      const existingPlanIndex = prev.findIndex(plan => plan.date === date);
      
      if (existingPlanIndex >= 0) {
        const updatedPlans = [...prev];
        updatedPlans[existingPlanIndex] = {
          ...updatedPlans[existingPlanIndex],
          meals: {
            ...updatedPlans[existingPlanIndex].meals,
            [mealType]: recipe
          }
        };
        return updatedPlans;
      } else {
        const newPlan: MealPlan = {
          id: date,
          date,
          meals: { [mealType]: recipe }
        };
        return [...prev, newPlan];
      }
    });

    // Auto-add ingredients to grocery list
    addRecipeIngredientsToGrocery(recipe);
  };

  const removeMealFromPlan = (date: string, mealType: 'breakfast' | 'lunch' | 'dinner') => {
    setMealPlans(prev => prev.map(plan => 
      plan.date === date 
        ? { ...plan, meals: { ...plan.meals, [mealType]: undefined } }
        : plan
    ));
  };

  const getMealPlan = (date: string) => {
    return mealPlans.find(plan => plan.date === date);
  };

  const addGroceryItem = (item: Omit<GroceryItem, 'id'>) => {
    const newItem: GroceryItem = {
      ...item,
      id: Date.now().toString()
    };
    setGroceryItems(prev => [...prev, newItem]);
  };

  const removeGroceryItem = (id: string) => {
    setGroceryItems(prev => prev.filter(item => item.id !== id));
  };

  const toggleGroceryItem = (id: string) => {
    setGroceryItems(prev => prev.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  const clearCheckedItems = () => {
    setGroceryItems(prev => prev.filter(item => !item.checked));
  };

  const addRecipeIngredientsToGrocery = (recipe: Recipe) => {
    // Add basic ingredients from recipe
    const ingredients = [
      ...(recipe.usedIngredients || []),
      ...(recipe.missedIngredients || [])
    ];

    ingredients.forEach(ingredient => {
      // Check if ingredient already exists
      const exists = groceryItems.some(item => 
        item.name.toLowerCase() === ingredient.name.toLowerCase()
      );

      if (!exists) {
        addGroceryItem({
          name: ingredient.name,
          quantity: ingredient.amount || 1,
          unit: ingredient.unit || 'pieces',
          aisle: ingredient.aisle || 'Other',
          checked: false,
          recipeId: recipe.id,
          recipeTitle: recipe.title
        });
      }
    });
  };

  const value: AppContextType = {
    user,
    isAuthenticated: !!user,
    login,
    logout,
    updateProfile,
    likedRecipes,
    toggleLikeRecipe,
    isRecipeLiked,
    mealPlans,
    addRecipeToMealPlan,
    removeMealFromPlan,
    getMealPlan,
    groceryItems,
    addGroceryItem,
    removeGroceryItem,
    toggleGroceryItem,
    clearCheckedItems,
    addRecipeIngredientsToGrocery,
    pendingMealAddition,
    setPendingMealAddition
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}