import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Alert, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Sparkles, ChefHat } from 'lucide-react-native';
import RecipeCard from '@/components/RecipeCard';
import LoadingCard from '@/components/LoadingCard';
import RecipeDetailModal from '@/components/RecipeDetailModal';
import { RecipeAPI } from '@/services/api';
import type { Recipe } from '@/types/recipe';

const POPULAR_SEARCHES = ['potato', 'chicken', 'pasta', 'vegetarian', 'dessert', 'healthy'];

export default function RecipeSearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [modalVisible, setModalVisible] = useState(false);

  const searchRecipes = async (query: string = searchQuery) => {
    if (!query.trim()) return;
    
    setLoading(true);
    setHasSearched(true);
    try {
      const data = await RecipeAPI.searchRecipes(query, undefined, undefined, 15);
      setRecipes(data.results || []);
    } catch (error) {
      Alert.alert('Error', 'Failed to search recipes. Please check your internet connection and try again.');
      console.error('Error searching recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadRandomRecipes = async () => {
    setLoading(true);
    try {
      const data = await RecipeAPI.getRandomRecipes(15);
      setRecipes(data.recipes || []);
    } catch (error) {
      Alert.alert('Error', 'Failed to load random recipes. Please try again.');
      console.error('Error loading random recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    if (hasSearched && searchQuery.trim()) {
      await searchRecipes();
    } else {
      await loadRandomRecipes();
    }
    setRefreshing(false);
  };

  const handlePopularSearch = (query: string) => {
    setSearchQuery(query);
    searchRecipes(query);
  };

  const handleRecipePress = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setSelectedRecipe(null);
  };

  const renderLoadingCards = () => {
    return Array.from({ length: 4 }, (_, index) => (
      <LoadingCard key={index} />
    ));
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>✨ Discover Amazing Recipes ✨</Text>
          <Text style={styles.subtitle}>
            Search for any ingredient or dish to find multiple recipe variations with detailed cooking instructions.
          </Text>
        </View>

        {/* Search Section */}
        <View style={styles.searchSection}>
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search for recipes... (e.g., 'potato', 'chicken curry', 'chocolate cake')"
              placeholderTextColor="#9CA3AF"
              onSubmitEditing={() => searchRecipes()}
              returnKeyType="search"
            />
            <TouchableOpacity 
              style={styles.searchButton} 
              onPress={() => searchRecipes()}
            >
              <Search color="#FFFFFF" size={20} strokeWidth={2} />
              <Text style={styles.searchButtonText}>Search</Text>
            </TouchableOpacity>
          </View>

          {/* Popular Searches */}
          <View style={styles.popularSection}>
            <Text style={styles.popularTitle}>📈 Popular searches:</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.popularScroll}>
              {POPULAR_SEARCHES.map((search) => (
                <TouchableOpacity
                  key={search}
                  style={styles.popularButton}
                  onPress={() => handlePopularSearch(search)}
                >
                  <Text style={styles.popularText}>{search}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Random Recipes Button */}
          <TouchableOpacity style={styles.randomButton} onPress={loadRandomRecipes}>
            <Sparkles color="#8B5CF6" size={20} strokeWidth={2} />
            <Text style={styles.randomButtonText}>Random Recipes</Text>
          </TouchableOpacity>
        </View>

        {/* Results or Empty State */}
        {!hasSearched && recipes.length === 0 ? (
          <View style={styles.emptyState}>
            <ChefHat color="#D1D5DB" size={64} strokeWidth={2} />
            <Text style={styles.emptyTitle}>Find Recipe Variations for Any Dish!</Text>
            <Text style={styles.emptyText}>
              Search for any ingredient like "potato" to discover multiple recipes, each with detailed cooking procedures and ingredients.
            </Text>
          </View>
        ) : (
          <View style={styles.resultsSection}>
            {hasSearched && searchQuery && (
              <View style={styles.resultsHeader}>
                <Search color="#10B981" size={20} strokeWidth={2} />
                <Text style={styles.resultsTitle}>
                  Found {recipes.length} Recipe Variations
                </Text>
              </View>
            )}

            {loading ? (
              renderLoadingCards()
            ) : recipes.length > 0 ? (
              recipes.map((recipe) => (
                <RecipeCard 
                  key={recipe.id} 
                  recipe={recipe} 
                  onPress={handleRecipePress}
                  showStats={false}
                />
              ))
            ) : hasSearched ? (
              <View style={styles.noResults}>
                <Text style={styles.noResultsTitle}>No recipes found</Text>
                <Text style={styles.noResultsText}>
                  Try searching for different ingredients or dish names.
                </Text>
              </View>
            ) : null}
          </View>
        )}
      </ScrollView>

      <RecipeDetailModal
        recipe={selectedRecipe}
        visible={modalVisible}
        onClose={closeModal}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F1F5F9',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
    textAlign: 'center',
  },
  searchSection: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 24,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  searchButton: {
    backgroundColor: '#8B5CF6',
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 14,
    gap: 8,
    shadowColor: '#8B5CF6',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  searchButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  popularSection: {
    marginBottom: 16,
  },
  popularTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginBottom: 8,
  },
  popularScroll: {
    marginBottom: 8,
  },
  popularButton: {
    backgroundColor: '#F1F5F9',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  popularText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#475569',
  },
  randomButton: {
    backgroundColor: '#F3F4F6',
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 8,
    borderWidth: 2,
    borderColor: '#8B5CF6',
    borderStyle: 'dashed',
  },
  randomButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#8B5CF6',
  },
  resultsSection: {
    marginHorizontal: 20,
    marginBottom: 24,
  },
  resultsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  resultsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#374151',
    marginTop: 16,
    marginBottom: 12,
    textAlign: 'center',
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  noResults: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 48,
    paddingHorizontal: 32,
  },
  noResultsTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    marginBottom: 8,
  },
  noResultsText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 22,
  },
});