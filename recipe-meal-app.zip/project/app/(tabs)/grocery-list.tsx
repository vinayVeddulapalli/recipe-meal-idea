import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ShoppingCart, Plus, Check, X, Package, DollarSign } from 'lucide-react-native';
import { useApp } from '@/contexts/AppContext';

export default function GroceryListScreen() {
  const { 
    groceryItems, 
    addGroceryItem, 
    removeGroceryItem, 
    toggleGroceryItem, 
    clearCheckedItems 
  } = useApp();
  const [newItemName, setNewItemName] = useState('');

  const addItem = () => {
    if (!newItemName.trim()) {
      Alert.alert('Error', 'Please enter an item name');
      return;
    }

    addGroceryItem({
      name: newItemName.trim(),
      quantity: 1,
      unit: 'pieces',
      aisle: 'Other',
      checked: false,
    });

    setNewItemName('');
  };

  const handleClearCheckedItems = () => {
    const checkedCount = groceryItems.filter(item => item.checked).length;
    if (checkedCount === 0) return;

    Alert.alert(
      'Clear Checked Items',
      `Are you sure you want to remove ${checkedCount} checked items?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Clear', 
          style: 'destructive',
          onPress: clearCheckedItems
        }
      ]
    );
  };

  const groupItemsByAisle = () => {
    const grouped = groceryItems.reduce((acc, item) => {
      if (!acc[item.aisle]) {
        acc[item.aisle] = [];
      }
      acc[item.aisle].push(item);
      return acc;
    }, {} as Record<string, typeof groceryItems>);

    return Object.entries(grouped).sort(([a], [b]) => a.localeCompare(b));
  };

  const checkedCount = groceryItems.filter(item => item.checked).length;
  const totalCount = groceryItems.length;
  const remainingCount = totalCount - checkedCount;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Smart Grocery List</Text>
        <Text style={styles.subtitle}>
          Automatically generated from your meal plan and organized by store sections.
        </Text>
        
        {totalCount === 0 && (
          <TouchableOpacity style={styles.mealPlanLink}>
            <Text style={styles.mealPlanLinkText}>
              Add recipes to your meal plan to automatically generate grocery items!
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <ShoppingCart color="#10B981" size={24} strokeWidth={2} />
          <View style={styles.statInfo}>
            <Text style={styles.statNumber}>{remainingCount}/{totalCount}</Text>
            <Text style={styles.statLabel}>Items Remaining</Text>
          </View>
        </View>
        
        <View style={styles.statCard}>
          <Check color="#059669" size={24} strokeWidth={2} />
          <View style={styles.statInfo}>
            <Text style={styles.statNumber}>{checkedCount}</Text>
            <Text style={styles.statLabel}>Items Completed</Text>
          </View>
        </View>
        
        <View style={styles.statCard}>
          <DollarSign color="#8B5CF6" size={24} strokeWidth={2} />
          <View style={styles.statInfo}>
            <Text style={styles.statNumber}>$0.00</Text>
            <Text style={styles.statLabel}>Estimated Total</Text>
          </View>
        </View>
      </View>

      {/* Add Item Section */}
      <View style={styles.addSection}>
        <Text style={styles.addTitle}>Add to List</Text>
        <Text style={styles.addSubtitle}>Add custom items to your grocery list</Text>
        
        <View style={styles.addContainer}>
          <TextInput
            style={styles.addInput}
            value={newItemName}
            onChangeText={setNewItemName}
            placeholder="Enter grocery item..."
            placeholderTextColor="#9CA3AF"
            onSubmitEditing={addItem}
            returnKeyType="done"
          />
          <TouchableOpacity 
            style={[styles.addButton, !newItemName.trim() && styles.addButtonDisabled]}
            onPress={addItem}
            disabled={!newItemName.trim()}
          >
            <Plus color="#FFFFFF" size={20} strokeWidth={2} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Grocery List */}
      <View style={styles.listSection}>
        <View style={styles.listHeader}>
          <Text style={styles.listTitle}>Your Grocery List</Text>
          <Text style={styles.listSubtitle}>Organized by store sections for efficient shopping</Text>
        </View>

        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          {totalCount > 0 ? (
            groupItemsByAisle().map(([aisle, items]) => (
              <View key={aisle} style={styles.aisleSection}>
                <View style={styles.aisleHeader}>
                  <Package color="#6B7280" size={20} strokeWidth={2} />
                  <Text style={styles.aisleTitle}>{aisle}</Text>
                  <Text style={styles.aisleCount}>
                    {items.filter(item => item.checked).length}/{items.length}
                  </Text>
                </View>
                
                {items.map((item) => (
                  <View key={item.id} style={[styles.itemCard, item.checked && styles.itemCardChecked]}>
                    <TouchableOpacity 
                      style={styles.itemContent}
                      onPress={() => toggleGroceryItem(item.id)}
                    >
                      <View style={[styles.checkbox, item.checked && styles.checkboxChecked]}>
                        {item.checked && <Check color="#FFFFFF" size={16} strokeWidth={2} />}
                      </View>
                      
                      <View style={styles.itemInfo}>
                        <Text style={[styles.itemName, item.checked && styles.itemNameChecked]}>
                          {item.name}
                        </Text>
                        <Text style={styles.itemQuantity}>
                          {item.quantity} {item.unit}
                        </Text>
                        {item.recipeTitle && (
                          <Text style={styles.itemRecipe}>
                            From: {item.recipeTitle}
                          </Text>
                        )}
                      </View>
                    </TouchableOpacity>
                    
                    <TouchableOpacity 
                      style={styles.removeButton}
                      onPress={() => removeGroceryItem(item.id)}
                    >
                      <X color="#EF4444" size={20} strokeWidth={2} />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>
            ))
          ) : (
            <View style={styles.emptyState}>
              <ShoppingCart color="#D1D5DB" size={64} strokeWidth={2} />
              <Text style={styles.emptyTitle}>Your grocery list is empty</Text>
              <Text style={styles.emptyText}>
                Add items manually or plan meals to automatically generate your shopping list
              </Text>
            </View>
          )}
        </ScrollView>
      </View>

      {/* Clear Button */}
      {checkedCount > 0 && (
        <View style={styles.clearContainer}>
          <TouchableOpacity 
            style={styles.clearButton}
            onPress={handleClearCheckedItems}
          >
            <Text style={styles.clearButtonText}>Clear {checkedCount} Checked Items</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
    textAlign: 'center',
  },
  mealPlanLink: {
    backgroundColor: '#EBF8FF',
    borderRadius: 12,
    padding: 12,
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  mealPlanLinkText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1D4ED8',
    textAlign: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 3,
  },
  statInfo: {
    flex: 1,
  },
  statNumber: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  addSection: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 20,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  addTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  addSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    marginBottom: 16,
  },
  addContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  addInput: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  addButton: {
    backgroundColor: '#10B981',
    borderRadius: 16,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 48,
  },
  addButtonDisabled: {
    backgroundColor: '#F3F4F6',
  },
  listSection: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  listHeader: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  listTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  listSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  scrollView: {
    flex: 1,
  },
  aisleSection: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  aisleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 8,
  },
  aisleTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    flex: 1,
  },
  aisleCount: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  itemCard: {
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  itemCardChecked: {
    opacity: 0.6,
    backgroundColor: '#F0FDF4',
    borderColor: '#10B981',
  },
  itemContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#D1D5DB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxChecked: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  itemNameChecked: {
    textDecorationLine: 'line-through',
    color: '#6B7280',
  },
  itemQuantity: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  itemRecipe: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#10B981',
    fontStyle: 'italic',
  },
  removeButton: {
    padding: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#374151',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
  clearContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  clearButton: {
    backgroundColor: '#EF4444',
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    shadowColor: '#EF4444',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  clearButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
});