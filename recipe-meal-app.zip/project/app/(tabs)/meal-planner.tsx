import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Calendar, Plus, Trash2, ChefHat, Clock, Users } from 'lucide-react-native';
import { useApp } from '@/contexts/AppContext';
import { RecipeAPI } from '@/services/api';
import type { Recipe, MealPlan } from '@/types/recipe';

const DAYS_OF_WEEK = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MEAL_TYPES = ['breakfast', 'lunch', 'dinner'] as const;

export default function MealPlannerScreen() {
  const [currentWeek, setCurrentWeek] = useState<Date>(new Date());
  const [loading, setLoading] = useState(false);
  const { 
    mealPlans, 
    addRecipeToMealPlan, 
    removeMealFromPlan, 
    getMealPlan,
    pendingMealAddition,
    setPendingMealAddition
  } = useApp();

  useEffect(() => {
    // Handle pending meal addition from recipe detail modal
    if (pendingMealAddition) {
      Alert.alert(
        'Add to Meal Plan',
        `Add "${pendingMealAddition.recipe.title}" to which meal?`,
        [
          { text: 'Cancel', style: 'cancel', onPress: () => setPendingMealAddition(null) },
          { 
            text: 'Breakfast', 
            onPress: () => handlePendingMealAddition('breakfast')
          },
          { 
            text: 'Lunch', 
            onPress: () => handlePendingMealAddition('lunch')
          },
          { 
            text: 'Dinner', 
            onPress: () => handlePendingMealAddition('dinner')
          },
        ]
      );
    }
  }, [pendingMealAddition]);

  const handlePendingMealAddition = (mealType: 'breakfast' | 'lunch' | 'dinner') => {
    if (!pendingMealAddition) return;

    const today = new Date().toISOString().split('T')[0];
    addRecipeToMealPlan(pendingMealAddition.recipe, today, mealType);
    pendingMealAddition.callback(today, mealType);
    setPendingMealAddition(null);
  };

  const getWeekStart = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day;
    return new Date(d.setDate(diff));
  };

  const getWeekDays = () => {
    const weekStart = getWeekStart(currentWeek);
    const days = [];
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(weekStart);
      date.setDate(weekStart.getDate() + i);
      days.push(date);
    }
    
    return days;
  };

  const addRandomMeal = async (date: string, mealType: keyof MealPlan['meals']) => {
    setLoading(true);
    try {
      const data = await RecipeAPI.getRandomRecipes(1);
      if (data.recipes && data.recipes.length > 0) {
        const recipe = data.recipes[0];
        addRecipeToMealPlan(recipe, date, mealType);
        Alert.alert('Meal Added!', `${recipe.title} has been added to your ${mealType}.`);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to add meal. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const removeMeal = (date: string, mealType: keyof MealPlan['meals']) => {
    removeMealFromPlan(date, mealType);
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newWeek = new Date(currentWeek);
    newWeek.setDate(currentWeek.getDate() + (direction === 'next' ? 7 : -7));
    setCurrentWeek(newWeek);
  };

  const formatDate = (date: Date) => {
    return {
      day: DAYS_OF_WEEK[date.getDay()],
      date: date.getDate(),
      month: date.toLocaleDateString('en-US', { month: 'short' })
    };
  };

  const getTotalMeals = () => {
    return mealPlans.reduce((total, plan) => {
      return total + Object.values(plan.meals).filter(meal => meal).length;
    }, 0);
  };

  const getTotalCookTime = () => {
    let totalTime = 0;
    mealPlans.forEach(plan => {
      Object.values(plan.meals).forEach(meal => {
        if (meal && meal.readyInMinutes) {
          totalTime += meal.readyInMinutes;
        }
      });
    });
    return totalTime;
  };

  const getTotalServings = () => {
    let totalServings = 0;
    mealPlans.forEach(plan => {
      Object.values(plan.meals).forEach(meal => {
        if (meal && meal.servings) {
          totalServings += meal.servings;
        }
      });
    });
    return totalServings;
  };

  const renderMealSlot = (date: Date, mealType: keyof MealPlan['meals']) => {
    const dateString = date.toISOString().split('T')[0];
    const mealPlan = getMealPlan(dateString);
    const meal = mealPlan?.meals[mealType];
    
    return (
      <View key={mealType} style={styles.mealSlot}>
        <Text style={styles.mealType}>
          {mealType.charAt(0).toUpperCase() + mealType.slice(1)}
        </Text>
        {meal ? (
          <View style={styles.mealCard}>
            <Text style={styles.mealTitle} numberOfLines={2}>
              {meal.title}
            </Text>
            <View style={styles.mealStats}>
              {meal.readyInMinutes && (
                <View style={styles.mealStat}>
                  <Clock color="#6B7280" size={12} strokeWidth={2} />
                  <Text style={styles.mealStatText}>{meal.readyInMinutes}min</Text>
                </View>
              )}
              {meal.servings && (
                <View style={styles.mealStat}>
                  <Users color="#6B7280" size={12} strokeWidth={2} />
                  <Text style={styles.mealStatText}>{meal.servings}</Text>
                </View>
              )}
            </View>
            <TouchableOpacity 
              style={styles.removeButton}
              onPress={() => removeMeal(dateString, mealType)}
            >
              <Trash2 color="#EF4444" size={16} strokeWidth={2} />
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity 
            style={styles.addMealButton}
            onPress={() => addRandomMeal(dateString, mealType)}
            disabled={loading}
          >
            <Plus color="#10B981" size={20} strokeWidth={2} />
            <Text style={styles.addMealText}>Add {mealType}</Text>
          </TouchableOpacity>
        )}
      </View>
    );
  };

  const weekDays = getWeekDays();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>SmartMeal</Text>
        <View style={styles.weekNavigation}>
          <TouchableOpacity style={styles.navButton} onPress={() => navigateWeek('prev')}>
            <Text style={styles.navButtonText}>Previous Week</Text>
          </TouchableOpacity>
          
          <View style={styles.weekInfo}>
            <Calendar color="#10B981" size={16} strokeWidth={2} />
            <Text style={styles.weekText}>
              {getWeekStart(currentWeek).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {
                (() => {
                  const weekEnd = new Date(getWeekStart(currentWeek));
                  weekEnd.setDate(weekEnd.getDate() + 6);
                  return weekEnd.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                })()
              }
            </Text>
          </View>
          
          <TouchableOpacity style={styles.navButton} onPress={() => navigateWeek('next')}>
            <Text style={styles.navButtonText}>Next Week</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.subtitle}>
          Click on empty meal slots to add random recipes or use "Add to Meal Plan" from recipe details
        </Text>
      </View>

      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <ChefHat color="#10B981" size={24} strokeWidth={2} />
          <View style={styles.statInfo}>
            <Text style={styles.statNumber}>{getTotalMeals()}</Text>
            <Text style={styles.statLabel}>Planned Meals</Text>
          </View>
        </View>
        
        <View style={styles.statCard}>
          <Clock color="#3B82F6" size={24} strokeWidth={2} />
          <View style={styles.statInfo}>
            <Text style={styles.statNumber}>{Math.floor(getTotalCookTime() / 60)}h</Text>
            <Text style={styles.statLabel}>Total Cook Time</Text>
          </View>
        </View>
        
        <View style={styles.statCard}>
          <Users color="#8B5CF6" size={24} strokeWidth={2} />
          <View style={styles.statInfo}>
            <Text style={styles.statNumber}>{getTotalServings()}</Text>
            <Text style={styles.statLabel}>Total Servings</Text>
          </View>
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {weekDays.map((date) => {
          const { day, date: dayNumber, month } = formatDate(date);
          
          return (
            <View key={date.toISOString()} style={styles.dayCard}>
              <View style={styles.dayHeader}>
                <View style={styles.dateInfo}>
                  <Text style={styles.dayName}>{day}</Text>
                  <Text style={styles.dateNumber}>{dayNumber}</Text>
                  <Text style={styles.monthName}>{month}</Text>
                </View>
              </View>
              
              <View style={styles.mealsContainer}>
                {MEAL_TYPES.map(mealType => renderMealSlot(date, mealType))}
              </View>
            </View>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
    marginBottom: 16,
    textAlign: 'center',
  },
  weekNavigation: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  navButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#F1F5F9',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  navButtonText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#475569',
  },
  weekInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  weekText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  subtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 3,
  },
  statInfo: {
    flex: 1,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  scrollView: {
    flex: 1,
  },
  dayCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginVertical: 8,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  dayHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  dateInfo: {
    alignItems: 'center',
    marginRight: 16,
  },
  dayName: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  dateNumber: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
  },
  monthName: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
  },
  mealsContainer: {
    gap: 16,
  },
  mealSlot: {
    borderLeftWidth: 4,
    borderLeftColor: '#10B981',
    paddingLeft: 16,
  },
  mealType: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#374151',
    marginBottom: 8,
    textTransform: 'capitalize',
  },
  mealCard: {
    backgroundColor: '#F8FAFC',
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  mealTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    flex: 1,
    marginRight: 8,
  },
  mealStats: {
    flexDirection: 'row',
    gap: 8,
    marginRight: 8,
  },
  mealStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  mealStatText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  removeButton: {
    padding: 4,
  },
  addMealButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F0FDF4',
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#10B981',
    borderStyle: 'dashed',
    gap: 8,
  },
  addMealText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
    textTransform: 'capitalize',
  },
});