import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, Alert, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Plus, Sparkles } from 'lucide-react-native';
import RecipeCard from '@/components/RecipeCard';
import LoadingCard from '@/components/LoadingCard';
import RecipeDetailModal from '@/components/RecipeDetailModal';
import { RecipeAPI } from '@/services/api';
import type { Recipe } from '@/types/recipe';

const QUICK_INGREDIENTS = [
  'chicken', 'beef', 'fish', 'rice', 'pasta', 'tomatoes', 
  'onions', 'garlic', 'cheese', 'eggs', 'potatoes', 'carrots'
];

export default function DiscoverScreen() {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [trendingRecipes, setTrendingRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    loadTrendingRecipes();
  }, []);

  useEffect(() => {
    if (ingredients.length > 0) {
      searchRecipesByIngredients();
    } else {
      setRecipes([]);
    }
  }, [ingredients]);

  const loadTrendingRecipes = async () => {
    setLoading(true);
    try {
      const data = await RecipeAPI.getRandomRecipes(6);
      setTrendingRecipes(data.recipes || []);
    } catch (error) {
      Alert.alert('Error', 'Failed to load trending recipes. Please try again.');
      console.error('Error loading trending recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const searchRecipesByIngredients = async () => {
    if (ingredients.length === 0) return;
    
    setLoading(true);
    try {
      const data = await RecipeAPI.searchRecipesByIngredients(ingredients, 15);
      setRecipes(data || []);
    } catch (error) {
      Alert.alert('Error', 'Failed to search recipes. Please check your internet connection and try again.');
      console.error('Error searching recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const addIngredient = () => {
    if (inputValue.trim() && !ingredients.includes(inputValue.trim().toLowerCase())) {
      setIngredients([...ingredients, inputValue.trim().toLowerCase()]);
      setInputValue('');
    }
  };

  const removeIngredient = (index: number) => {
    const newIngredients = ingredients.filter((_, i) => i !== index);
    setIngredients(newIngredients);
  };

  const addQuickIngredient = (ingredient: string) => {
    if (!ingredients.includes(ingredient)) {
      setIngredients([...ingredients, ingredient]);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    if (ingredients.length > 0) {
      await searchRecipesByIngredients();
    } else {
      await loadTrendingRecipes();
    }
    setRefreshing(false);
  };

  const handleRecipePress = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setSelectedRecipe(null);
  };

  const renderTrendingRecipes = () => (
    <View style={styles.trendingSection}>
      <View style={styles.sectionHeader}>
        <Sparkles color="#10B981" size={24} strokeWidth={2} />
        <Text style={styles.sectionTitle}>Trending Recipes</Text>
        <TouchableOpacity onPress={loadTrendingRecipes}>
          <Text style={styles.refreshText}>Refresh</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
        {loading ? (
          Array.from({ length: 3 }, (_, index) => (
            <View key={index} style={styles.trendingCard}>
              <LoadingCard />
            </View>
          ))
        ) : (
          trendingRecipes.map((recipe) => (
            <View key={recipe.id} style={styles.trendingCard}>
              <RecipeCard 
                recipe={recipe} 
                onPress={handleRecipePress}
                showStats={false}
                variant="trending"
              />
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );

  const renderSearchResults = () => {
    if (ingredients.length === 0) return null;

    return (
      <View style={styles.resultsSection}>
        <View style={styles.resultsHeader}>
          <Search color="#10B981" size={20} strokeWidth={2} />
          <Text style={styles.resultsTitle}>Found {recipes.length} Recipe Variations</Text>
        </View>
        
        {loading ? (
          Array.from({ length: 4 }, (_, index) => (
            <LoadingCard key={index} />
          ))
        ) : recipes.length > 0 ? (
          recipes.map((recipe) => (
            <RecipeCard 
              key={recipe.id} 
              recipe={recipe} 
              onPress={handleRecipePress}
              showStats={true}
            />
          ))
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>No recipes found</Text>
            <Text style={styles.emptyText}>
              Try adding different ingredients or removing some to get more results.
            </Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Discover Recipes</Text>
          <Text style={styles.subtitle}>
            Search by ingredients you have or explore our curated collection.
          </Text>
        </View>

        {/* Search by Ingredients Section */}
        <View style={styles.searchSection}>
          <Text style={styles.searchTitle}>🔍 Search by Ingredients</Text>
          
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={inputValue}
              onChangeText={setInputValue}
              placeholder="Add ingredients (e.g., chicken, rice, tomatoes)"
              placeholderTextColor="#9CA3AF"
              onSubmitEditing={addIngredient}
              returnKeyType="done"
            />
            <TouchableOpacity 
              style={[styles.addButton, !inputValue.trim() && styles.addButtonDisabled]} 
              onPress={addIngredient}
              disabled={!inputValue.trim()}
            >
              <Plus color={!inputValue.trim() ? "#D1D5DB" : "#FFFFFF"} size={20} strokeWidth={2} />
            </TouchableOpacity>
          </View>

          {/* Quick Add Ingredients */}
          <View style={styles.quickAddSection}>
            <Text style={styles.quickAddTitle}>Quick add:</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.quickAddScroll}>
              {QUICK_INGREDIENTS.map((ingredient) => (
                <TouchableOpacity
                  key={ingredient}
                  style={[
                    styles.quickAddButton,
                    ingredients.includes(ingredient) && styles.quickAddButtonActive
                  ]}
                  onPress={() => addQuickIngredient(ingredient)}
                  disabled={ingredients.includes(ingredient)}
                >
                  <Text style={[
                    styles.quickAddText,
                    ingredients.includes(ingredient) && styles.quickAddTextActive
                  ]}>
                    {ingredient}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Selected Ingredients */}
          {ingredients.length > 0 && (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.ingredientsContainer}>
              {ingredients.map((ingredient, index) => (
                <View key={index} style={styles.ingredientTag}>
                  <Text style={styles.ingredientText}>
                    {ingredient.charAt(0).toUpperCase() + ingredient.slice(1)}
                  </Text>
                  <TouchableOpacity 
                    onPress={() => removeIngredient(index)}
                    style={styles.removeButton}
                  >
                    <Text style={styles.removeButtonText}>×</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          )}

          {/* Find Recipes Button */}
          {ingredients.length > 0 && (
            <TouchableOpacity style={styles.findButton} onPress={searchRecipesByIngredients}>
              <Search color="#FFFFFF" size={20} strokeWidth={2} />
              <Text style={styles.findButtonText}>Find Recipes with Your Ingredients</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Search Results */}
        {renderSearchResults()}

        {/* Trending Recipes */}
        {ingredients.length === 0 && renderTrendingRecipes()}
      </ScrollView>

      <RecipeDetailModal
        recipe={selectedRecipe}
        visible={modalVisible}
        onClose={closeModal}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
  },
  searchSection: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 24,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  searchTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    paddingHorizontal: 16,
    paddingVertical: 4,
    marginBottom: 16,
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#111827',
    paddingVertical: 12,
  },
  addButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    padding: 10,
    marginLeft: 8,
  },
  addButtonDisabled: {
    backgroundColor: '#F3F4F6',
  },
  quickAddSection: {
    marginBottom: 16,
  },
  quickAddTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginBottom: 8,
  },
  quickAddScroll: {
    marginBottom: 8,
  },
  quickAddButton: {
    backgroundColor: '#F3F4F6',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  quickAddButtonActive: {
    backgroundColor: '#ECFDF5',
    borderColor: '#10B981',
  },
  quickAddText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  quickAddTextActive: {
    color: '#047857',
  },
  ingredientsContainer: {
    marginBottom: 16,
  },
  ingredientTag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ECFDF5',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  ingredientText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#047857',
    marginRight: 6,
  },
  removeButton: {
    padding: 2,
  },
  removeButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#EF4444',
  },
  findButton: {
    backgroundColor: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    shadowColor: '#10B981',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  findButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  resultsSection: {
    marginHorizontal: 20,
    marginBottom: 24,
  },
  resultsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  resultsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
  },
  trendingSection: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    flex: 1,
  },
  refreshText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
  },
  horizontalScroll: {
    paddingLeft: 20,
  },
  trendingCard: {
    width: 280,
    marginRight: 16,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 48,
    paddingHorizontal: 32,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 22,
  },
});