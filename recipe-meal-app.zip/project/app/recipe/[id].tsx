import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { 
  ArrowLeft, 
  Clock, 
  Users, 
  Heart, 
  BookOpen, 
  ChefHat,
  Plus,
  Check
} from 'lucide-react-native';
import { RecipeAPI } from '@/services/api';
import type { RecipeDetails } from '@/types/recipe';

export default function RecipeDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [recipe, setRecipe] = useState<RecipeDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSaved, setIsSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'ingredients' | 'instructions' | 'nutrition'>('ingredients');

  useEffect(() => {
    if (id) {
      loadRecipeDetails();
    }
  }, [id]);

  const loadRecipeDetails = async () => {
    try {
      const data = await RecipeAPI.getRecipeInformation(Number(id));
      setRecipe(data);
    } catch (error) {
      Alert.alert('Error', 'Failed to load recipe details. Please try again.');
      console.error('Error loading recipe details:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSaved = () => {
    setIsSaved(!isSaved);
    Alert.alert(
      isSaved ? 'Recipe Removed' : 'Recipe Saved', 
      isSaved ? 'Recipe removed from your saved recipes.' : 'Recipe saved to your collection!'
    );
  };

  const addToMealPlan = () => {
    Alert.alert(
      'Add to Meal Plan',
      'This would allow you to add this recipe to a specific day and meal in your meal plan.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Add to Plan', onPress: () => {
          Alert.alert('Added!', 'Recipe added to your meal plan.');
        }}
      ]
    );
  };

  const addIngredientsToGroceryList = () => {
    Alert.alert(
      'Add to Grocery List',
      'This would add all the recipe ingredients to your grocery list.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Add Ingredients', onPress: () => {
          Alert.alert('Added!', 'Ingredients added to your grocery list.');
        }}
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading recipe...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!recipe) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Recipe not found</Text>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const renderIngredients = () => (
    <View style={styles.tabContent}>
      <View style={styles.ingredientsHeader}>
        <Text style={styles.ingredientsTitle}>Ingredients</Text>
        <TouchableOpacity 
          style={styles.addToListButton}
          onPress={addIngredientsToGroceryList}
        >
          <Plus color="#10B981" size={16} strokeWidth={2} />
          <Text style={styles.addToListText}>Add to List</Text>
        </TouchableOpacity>
      </View>
      
      {recipe.extendedIngredients?.map((ingredient, index) => (
        <View key={index} style={styles.ingredientItem}>
          <View style={styles.ingredientBullet} />
          <Text style={styles.ingredientText}>
            {ingredient.amount} {ingredient.unit} {ingredient.name}
          </Text>
        </View>
      ))}
    </View>
  );

  const renderInstructions = () => (
    <View style={styles.tabContent}>
      <Text style={styles.instructionsTitle}>Instructions</Text>
      
      {recipe.analyzedInstructions?.[0]?.steps.map((step, index) => (
        <View key={index} style={styles.instructionStep}>
          <View style={styles.stepNumber}>
            <Text style={styles.stepNumberText}>{step.number}</Text>
          </View>
          <Text style={styles.stepText}>{step.step}</Text>
        </View>
      )) || (
        <Text style={styles.noInstructionsText}>
          {recipe.instructions || 'No instructions available for this recipe.'}
        </Text>
      )}
    </View>
  );

  const renderNutrition = () => (
    <View style={styles.tabContent}>
      <Text style={styles.nutritionTitle}>Nutrition Information</Text>
      
      <View style={styles.nutritionGrid}>
        <View style={styles.nutritionItem}>
          <Text style={styles.nutritionValue}>{recipe.healthScore}</Text>
          <Text style={styles.nutritionLabel}>Health Score</Text>
        </View>
        <View style={styles.nutritionItem}>
          <Text style={styles.nutritionValue}>${(recipe.pricePerServing / 100).toFixed(2)}</Text>
          <Text style={styles.nutritionLabel}>Per Serving</Text>
        </View>
        <View style={styles.nutritionItem}>
          <Text style={styles.nutritionValue}>{recipe.readyInMinutes}</Text>
          <Text style={styles.nutritionLabel}>Minutes</Text>
        </View>
        <View style={styles.nutritionItem}>
          <Text style={styles.nutritionValue}>{recipe.servings}</Text>
          <Text style={styles.nutritionLabel}>Servings</Text>
        </View>
      </View>

      <View style={styles.dietTags}>
        {recipe.vegetarian && <View style={styles.dietTag}><Text style={styles.dietTagText}>Vegetarian</Text></View>}
        {recipe.vegan && <View style={styles.dietTag}><Text style={styles.dietTagText}>Vegan</Text></View>}
        {recipe.glutenFree && <View style={styles.dietTag}><Text style={styles.dietTagText}>Gluten Free</Text></View>}
        {recipe.dairyFree && <View style={styles.dietTag}><Text style={styles.dietTagText}>Dairy Free</Text></View>}
        {recipe.veryHealthy && <View style={styles.dietTag}><Text style={styles.dietTagText}>Very Healthy</Text></View>}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity style={styles.backIconButton} onPress={() => router.back()}>
            <ArrowLeft color="#FFFFFF" size={24} strokeWidth={2} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.saveButton} onPress={toggleSaved}>
            <Heart 
              color={isSaved ? "#EF4444" : "#FFFFFF"} 
              size={24} 
              strokeWidth={2}
              fill={isSaved ? "#EF4444" : "transparent"}
            />
          </TouchableOpacity>
        </View>

        {/* Recipe Image */}
        <Image 
          source={{ uri: recipe.image || 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg' }}
          style={styles.recipeImage}
          resizeMode="cover"
        />

        {/* Recipe Info */}
        <View style={styles.recipeInfo}>
          <Text style={styles.recipeTitle}>{recipe.title}</Text>
          
          <View style={styles.recipeStats}>
            <View style={styles.statItem}>
              <Clock color="#6B7280" size={20} strokeWidth={2} />
              <Text style={styles.statText}>{recipe.readyInMinutes} min</Text>
            </View>
            <View style={styles.statItem}>
              <Users color="#6B7280" size={20} strokeWidth={2} />
              <Text style={styles.statText}>{recipe.servings} servings</Text>
            </View>
            <View style={styles.statItem}>
              <Heart color="#EF4444" size={20} strokeWidth={2} />
              <Text style={styles.statText}>{recipe.aggregateLikes} likes</Text>
            </View>
          </View>

          {recipe.summary && (
            <Text style={styles.recipeSummary}>
              {recipe.summary.replace(/<[^>]*>/g, '')}
            </Text>
          )}
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.primaryButton} onPress={addToMealPlan}>
            <ChefHat color="#FFFFFF" size={20} strokeWidth={2} />
            <Text style={styles.primaryButtonText}>Add to Meal Plan</Text>
          </TouchableOpacity>
        </View>

        {/* Tabs */}
        <View style={styles.tabsContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'ingredients' && styles.activeTab]}
            onPress={() => setActiveTab('ingredients')}
          >
            <Text style={[styles.tabText, activeTab === 'ingredients' && styles.activeTabText]}>
              Ingredients
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'instructions' && styles.activeTab]}
            onPress={() => setActiveTab('instructions')}
          >
            <Text style={[styles.tabText, activeTab === 'instructions' && styles.activeTabText]}>
              Instructions
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'nutrition' && styles.activeTab]}
            onPress={() => setActiveTab('nutrition')}
          >
            <Text style={[styles.tabText, activeTab === 'nutrition' && styles.activeTabText]}>
              Nutrition
            </Text>
          </TouchableOpacity>
        </View>

        {/* Tab Content */}
        {activeTab === 'ingredients' && renderIngredients()}
        {activeTab === 'instructions' && renderInstructions()}
        {activeTab === 'nutrition' && renderNutrition()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    position: 'absolute',
    top: 50,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    zIndex: 1,
  },
  backIconButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 20,
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 20,
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  recipeImage: {
    width: '100%',
    height: 300,
  },
  recipeInfo: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    marginTop: -20,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  recipeTitle: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 16,
    lineHeight: 32,
  },
  recipeStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
    paddingVertical: 16,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  recipeSummary: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    lineHeight: 24,
  },
  actionButtons: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  primaryButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  primaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 4,
    marginBottom: 16,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#10B981',
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  tabContent: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 16,
    marginBottom: 32,
  },
  ingredientsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  ingredientsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#111827',
  },
  addToListButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ECFDF5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  addToListText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
    marginLeft: 4,
  },
  ingredientItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  ingredientBullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
    marginRight: 12,
  },
  ingredientText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    flex: 1,
  },
  instructionsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 16,
  },
  instructionStep: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  stepNumberText: {
    fontSize: 14,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  stepText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#374151',
    flex: 1,
    lineHeight: 24,
  },
  noInstructionsText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 32,
  },
  nutritionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#111827',
    marginBottom: 16,
  },
  nutritionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  nutritionItem: {
    width: '48%',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  nutritionValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
    marginBottom: 4,
  },
  nutritionLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  dietTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dietTag: {
    backgroundColor: '#ECFDF5',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#10B981',
  },
  dietTagText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#047857',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  errorText: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#374151',
    marginBottom: 16,
  },
  backButton: {
    backgroundColor: '#10B981',
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  backButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});